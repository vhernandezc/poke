/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejeutar;

import ventanas.ventanaUsuarios;
import ventanas.ventana_pokedex;

/**
 *
 * @author vh367
 */
public class ejecutarLogin {
    public static void main (String[]args){//metodo para poder ejecutar nuestro login
       ventanaUsuarios registrar=new ventanaUsuarios();
       registrar.setVisible(true);
    }
}
