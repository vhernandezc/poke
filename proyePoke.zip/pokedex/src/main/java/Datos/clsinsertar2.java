/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import com.mycompany.pokedex.Clsconexion;
import com.mycompany.pokedex.clsusuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author vh367
 */
public class clsinsertar2 {
    private static final String SQL_SELECT="select*from tb_favoritos";
    private static final String SQL_INSERT="insert into tb_favoritos(usuario,contraseña) values(?,?)";
     public boolean select_validacion(clsusuario datos){
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        clsusuario usuario = new clsusuario();
        boolean tiene_permiso = false;
        
      try {
            String condicion = SQL_SELECT + " where  usuario='"+datos.getUsuario()+"'"+" and contraseña='"+datos.getContraseña()+"'";
            
            stmt = conn.prepareStatement(condicion);//y mandamos a llamar a la instrucion select
            rs = stmt.executeQuery();//cuando ejecute el query devuelve un tipo de dato rs
            while(rs.next()){
                tiene_permiso = true;
             
                String username = rs.getString("usuario");
                String password = rs.getString("contraseña");
                
                
                 usuario = new clsusuario();
               
                usuario.setUsuario(username);
                usuario.setContraseña(password);
                
                                
                
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }finally{
            Clsconexion.close(rs);//mandamos
            Clsconexion.close(stmt);
            Clsconexion.close(conn);
        }
        return tiene_permiso; 
            }
     
     
      public int insert(clsinsertar usu){
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        try {
            conn = Clsconexion.getConnection();
            stmt = conn.prepareStatement(SQL_INSERT);
            stmt.setString(1, usu.getUsuario());
            stmt.setString(2, usu.getContraseña());
             
           
           
           
            
            System.out.println("empleado agregado...");
            rows = stmt.executeUpdate();
            System.out.println("Registros afectados:" + rows);
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            Clsconexion.close(stmt);
            Clsconexion.close(conn);
        }
        
      
  
        
        return rows;}
  
     
     
     
}
