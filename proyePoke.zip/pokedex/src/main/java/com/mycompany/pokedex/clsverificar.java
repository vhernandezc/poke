/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pokedex;

import Datos.clsinsertar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author vh367
 */
public class clsverificar {
    private static final String SQL_SELECT="select*from tb_favoritos";
     private static final String SQL_INSERT="insert into tb_favoritos(usuario,contraseña,favoritos,speciesU,colorU,capture_rateU,habitatU, base_experienceU) values(?,?,?,?,?,?,?,?)";
     public boolean select_validacion(clsusuario datos){
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        clsusuario usuario = new clsusuario();
        boolean tiene_permiso = false;
        
        try {
            conn = Clsconexion.getConnection();//hacemos la conexion    usuario='"+datos.getUsuario()+"'"+" and contraseña='"+datos.getContraseña()+"'"+"
            String condicion = SQL_SELECT + " where  usuario='"+datos.getUsuario()+"'"+" and contraseña='"+datos.getContraseña()+"'"+"and favoritos='"+datos.getFavoritos()+
                    "'"+"and colorU='"+datos.getColorU()+"'"+"and speciesU='"+datos.getSpeciesU()+"'"+"and base_experienceU='"+datos.getBase_experienceU()+
                    "'"+"and capture_rateU='"+datos.getCapture_rateU()+"'"+"and habitatU='"+datos.getHabitatU()+"'";
                     
            stmt = conn.prepareStatement(condicion);//y mandamos a llamar a la instrucion select
            rs = stmt.executeQuery();//cuando ejecute el query devuelve un tipo de dato rs
            while(rs.next()){
                tiene_permiso = true;
             
                String username = rs.getString("usuario");
                String contraseña = rs.getString("contraseña");
                String favoritos=rs.getString("favoritos");
                String habitatU=rs.getString("habitatU");
                String capture_rateU=rs.getString("capture_rateU");
                String colorU=rs.getString("colorU");
                String speciesU=rs.getString("speciesU");
                String base_experienceU=rs.getString("base_experienceU");
                
                usuario = new clsusuario();
               
                usuario.setUsuario(username);
                usuario.setContraseña(contraseña);
                usuario.setBase_experienceU(base_experienceU);
                usuario.setCapture_rateU(capture_rateU);
                usuario.setColorU(colorU);
                usuario.setFavoritos(favoritos);
                usuario.setHabitatU(habitatU);
                usuario.setSpeciesU(speciesU);
                                
                
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }finally{
            Clsconexion.close(rs);//mandamos
            Clsconexion.close(stmt);
            Clsconexion.close(conn);
        }
        return tiene_permiso; 
    
}
      public int insert(clsinsertar usu){
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        try {
            conn = Clsconexion.getConnection();
            stmt = conn.prepareStatement(SQL_INSERT);
            stmt.setString(1, usu.getUsuario());
            stmt.setString(2, usu.getContraseña());
              stmt.setString(3, usu.getBase_experienceU());
             stmt.setString(4, usu.getCapture_rateU());
             stmt.setString(5, usu.getColorU());
             stmt.setString(6,usu.getFavoritos());
               stmt.setString(7, usu.getHabitatU());
             stmt.setString(8, usu.getSpeciesU());
           
           
           
            
            System.out.println("empleado agregado...");
            rows = stmt.executeUpdate();
            System.out.println("Registros afectados:" + rows);
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        finally{
            Clsconexion.close(stmt);
            Clsconexion.close(conn);
        }
        
      
  
        
        return rows;}
  
}
