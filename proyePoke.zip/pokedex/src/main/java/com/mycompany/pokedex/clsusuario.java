/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pokedex;

/**
 *
 * @author vh367
 */
public class clsusuario {
    private String usuario;
    private String contraseña;
    private String colorU;
    private String speciesU;
     private String capture_rateU;
      private String habitatU;
       private String base_experienceU;
        private String favoritos;
    

    
    public clsusuario(){
        
    }
    
        
    
    public clsusuario(String usuario, String contraseña){
        this.usuario=usuario;
        this.contraseña=contraseña;
       
    /**
     * @return the username
     */}
     public String toString() {
        return "usuario{" +  " usuario=" +usuario + ", contraseña=" + contraseña + '}';
        
    
    }

    /**
     * @return the usuario
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    /**
     * @return the contraseña
     */
    public String getContraseña() {
        return contraseña;
    }

    /**
     * @param contraseña the contraseña to set
     */
    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    /**
     * @return the colorU
     */
    public String getColorU() {
        return colorU;
    }

    /**
     * @param colorU the colorU to set
     */
    public void setColorU(String colorU) {
        this.colorU = colorU;
    }

    /**
     * @return the speciesU
     */
    public String getSpeciesU() {
        return speciesU;
    }

    /**
     * @param speciesU the speciesU to set
     */
    public void setSpeciesU(String speciesU) {
        this.speciesU = speciesU;
    }

    /**
     * @return the capture_rateU
     */
    public String getCapture_rateU() {
        return capture_rateU;
    }

    /**
     * @param capture_rateU the capture_rateU to set
     */
    public void setCapture_rateU(String capture_rateU) {
        this.capture_rateU = capture_rateU;
    }

    /**
     * @return the habitatU
     */
    public String getHabitatU() {
        return habitatU;
    }

    /**
     * @param habitatU the habitatU to set
     */
    public void setHabitatU(String habitatU) {
        this.habitatU = habitatU;
    }

    /**
     * @return the base_experienceU
     */
    public String getBase_experienceU() {
        return base_experienceU;
    }

    /**
     * @param base_experienceU the base_experienceU to set
     */
    public void setBase_experienceU(String base_experienceU) {
        this.base_experienceU = base_experienceU;
    }

    /**
     * @return the favoritos
     */
    public String getFavoritos() {
        return favoritos;
    }

    /**
     * @param favoritos the favoritos to set
     */
    public void setFavoritos(String favoritos) {
        this.favoritos = favoritos;
    }
    
}