/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;

import Datos.clsDatos;
import Datos.clsinsertar;
import com.mycompany.pokedex.clsverificar;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.sql.*;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
/**
 *
 * @author vh367
 */
public class ventana_pokedex extends javax.swing.JFrame {
   
    
    
     BufferedImage  buffer1 = null;
    Image imagen1 = null;
    int contador = 0;
    Statement estado;
    ResultSet resultadoConsulta;
    Connection conexion;
    
    @Override
    public void paint (Graphics g){
        super.paintComponents(g);
        Graphics2D g2 = (Graphics2D) imagenPoke.getGraphics();
        
        g2.drawImage(buffer1, 0, 0,imagenPoke.getWidth(),imagenPoke.getHeight(),null);
        
    /**
     * Creates new form ventana_pokedex
     */
    }
    public ventana_pokedex() {
        
        
     initComponents();
   
     lblcolor.setVisible(false);
              lblspecies.setVisible(false);
              lblcapture_rate.setVisible(false);
              lblbase_experience.setVisible(false);
        //para centrar la ventana
        this.setLocationRelativeTo(null);
        this.setTitle("Ventana_pokedex");
        
        try {
           // imagen1 = ImageI0.read(getClass().getResource(""));
           imagen1 = ImageIO.read(new File("C:\\Users\\vh367\\OneDrive\\Desktop\\datos\\imagenes\\black-white.png"));
        } catch (IOException ex) {
           ex.printStackTrace(System.out);
        }
        
        buffer1 = (BufferedImage) imagenPoke.createImage(imagenPoke.getWidth(),imagenPoke.getHeight());
        
        Graphics2D g2 = buffer1.createGraphics();
        dibujaElPokemonQueEstaEnLaPosicion(30);
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String JDBC_URL="jdbc:mysql://localhost:3306/test?zeroDateTimeBehavior=convertToNull&useSSL=false&useTimezone=true&serverTimezone=UTC";
            
            conexion = DriverManager.getConnection(JDBC_URL,"root","Dacruz4032");
            estado = (Statement) conexion.createStatement();
            
     
        } catch (ClassNotFoundException ex) {
           ex.printStackTrace(System.out);
           System.out.println("Hay error de Base de Datos");
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            System.out.println("Hay error de Base de Datos");
        }
        
     
        
    }
     private void dibujaElPokemonQueEstaEnLaPosicion(int posicion){
        int fila = posicion/31;
        int columna = posicion % 31;
        Graphics2D g2 = (Graphics2D) buffer1.getGraphics();
        g2.setColor(Color.pink);
        g2.fillRect(0, 0, //pinta el fondo del jpanel negro
                imagenPoke .getWidth(),
                imagenPoke.getHeight());
        g2.drawImage(imagen1,
                0, //posicion X inicial dentro del jpanel
                0, // posicion Y inicial dentro del jpanel
                imagenPoke.getWidth(), //ancho del jpanel
                imagenPoke.getHeight(), //alto del jpanel
                columna*96, //posicion inicial X dentro de la imagen de todos los pokemon
                fila*96, //posicion inicial Y dentro de la imagen de todos los pokemon
                columna*96 + 96, //posicion final X
                fila*96 + 96, //posicion final Y
                null //si no lo pones no va
                );
        repaint();
    
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        imagenPoke = new javax.swing.JPanel();
        nombrepoke = new javax.swing.JLabel();
        izquierda = new javax.swing.JButton();
        derecha = new javax.swing.JButton();
        nombrePoke = new javax.swing.JLabel();
        query = new javax.swing.JLabel();
        prueba = new javax.swing.JButton();
        jcomboHabitats = new javax.swing.JComboBox<>();
        jcomboPokemones = new javax.swing.JComboBox<>();
        btncolor = new javax.swing.JButton();
        jcombocolor = new javax.swing.JComboBox<>();
        btnbuscarNombre = new javax.swing.JButton();
        jcomboNombres = new javax.swing.JComboBox<>();
        lblprueba = new javax.swing.JLabel();
        btnfavoritos = new javax.swing.JButton();
        lblspecies = new javax.swing.JLabel();
        lblcolor = new javax.swing.JLabel();
        lblcapture_rate = new javax.swing.JLabel();
        lblbase_experience = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        imagenPoke.setBackground(new java.awt.Color(0, 0, 0));
        imagenPoke.setBorder(javax.swing.BorderFactory.createMatteBorder(4, 4, 4, 4, new java.awt.Color(0, 255, 204)));

        javax.swing.GroupLayout imagenPokeLayout = new javax.swing.GroupLayout(imagenPoke);
        imagenPoke.setLayout(imagenPokeLayout);
        imagenPokeLayout.setHorizontalGroup(
            imagenPokeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        imagenPokeLayout.setVerticalGroup(
            imagenPokeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        izquierda.setText("<= izquierda");
        izquierda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                izquierdaActionPerformed(evt);
            }
        });

        derecha.setText("derecha ==>");
        derecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                derechaActionPerformed(evt);
            }
        });

        nombrePoke.setBackground(new java.awt.Color(51, 0, 102));
        nombrePoke.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        nombrePoke.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nombrePoke.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Nombre", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tw Cen MT", 1, 12))); // NOI18N

        query.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Habitat", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N

        prueba.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        prueba.setText("ver habitats  ==>>");
        prueba.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pruebaActionPerformed(evt);
            }
        });

        jcomboHabitats.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jcomboHabitats.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Habitats" }));
        jcomboHabitats.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcomboHabitatsActionPerformed(evt);
            }
        });

        jcomboPokemones.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jcomboPokemones.setMaximumRowCount(800);
        jcomboPokemones.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pokemones" }));
        jcomboPokemones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcomboPokemonesActionPerformed(evt);
            }
        });

        btncolor.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btncolor.setText("por color ==>>");
        btncolor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncolorActionPerformed(evt);
            }
        });

        jcombocolor.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jcombocolor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Colores" }));
        jcombocolor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcombocolorActionPerformed(evt);
            }
        });

        btnbuscarNombre.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnbuscarNombre.setText("por nombre ==>");
        btnbuscarNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbuscarNombreActionPerformed(evt);
            }
        });

        jcomboNombres.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jcomboNombres.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "nombres" }));
        jcomboNombres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcomboNombresActionPerformed(evt);
            }
        });

        btnfavoritos.setText("agregar a favoritos");
        btnfavoritos.setActionCommand("");
        btnfavoritos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfavoritosActionPerformed(evt);
            }
        });

        lblspecies.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Species", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Yu Gothic Medium", 1, 12))); // NOI18N

        lblcolor.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Color", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tw Cen MT", 1, 12))); // NOI18N

        lblcapture_rate.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Capture_rate", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Trebuchet MS", 1, 12))); // NOI18N

        lblbase_experience.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Base_experience", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tw Cen MT", 1, 12))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(155, 155, 155)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(nombrepoke)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(btncolor, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(prueba)
                                                .addComponent(btnbuscarNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(54, 54, 54)
                                            .addComponent(jcomboNombres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGap(199, 199, 199)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(jcomboHabitats, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jcombocolor, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addComponent(nombrePoke, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(60, 60, 60)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(btnfavoritos)
                                                .addComponent(jcomboPokemones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGap(28, 28, 28)))
                            .addGap(4, 4, 4))
                        .addGroup(layout.createSequentialGroup()
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblprueba)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(query, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(102, 102, 102)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(izquierda)
                                    .addGap(18, 18, 18)
                                    .addComponent(derecha))
                                .addComponent(imagenPoke, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(lblbase_experience, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblcapture_rate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblcolor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblspecies, javax.swing.GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE)))))
                .addContainerGap(195, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 3, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jcomboPokemones, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(prueba)
                        .addComponent(jcomboHabitats, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(nombrepoke)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnfavoritos)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btncolor, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jcombocolor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnbuscarNombre)
                            .addComponent(jcomboNombres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addComponent(lblprueba))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(64, 64, 64)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(nombrePoke, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(query, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addComponent(lblcolor, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblcapture_rate, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(imagenPoke, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(derecha)
                                    .addComponent(izquierda))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblbase_experience, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblspecies, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(421, 590, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void izquierdaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_izquierdaActionPerformed
        
      
             
             contador --;
             if(contador<=0){
             contador = 1;
             }
             dibujaElPokemonQueEstaEnLaPosicion(contador-1);
             try {
             int id = contador;
             String qr = "select * from pokemon where id="+id;
             
             resultadoConsulta = estado.executeQuery(qr);
             
             if(resultadoConsulta.next()){
             nombrePoke.setText(resultadoConsulta.getString(2));
             query.setText(resultadoConsulta.getString("habitat"));
             }else{
             nombrePoke.setText("El pokemon no esta o no existe en el pokedex");
             
             }
             } catch (SQLException ex) {
             Logger.getLogger(ventana_pokedex.class.getName()).log(Level.SEVERE, null, ex);
             }
           // TODO add your handling code here:
        
    }//GEN-LAST:event_izquierdaActionPerformed

    private void derechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_derechaActionPerformed
        
        
       dibujaElPokemonQueEstaEnLaPosicion(contador);
       
        String cuerito = "Select * from pokemon where id="+(contador+1);
        
        
        try {
            resultadoConsulta = estado.executeQuery(cuerito);
            if (resultadoConsulta.next()){
                nombrePoke.setText(resultadoConsulta.getString(2));
                 query.setText(resultadoConsulta.getString("habitat"));
            } else {
                nombrePoke.setText("no existe");
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            System.out.println("Clavo con sql");
        }
        
        contador++;
        if (contador >=649){
            contador = 649;
        }
      
              // TODO add your handling code here:
    }//GEN-LAST:event_derechaActionPerformed
      
    private void pruebaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pruebaActionPerformed
         // String cuerito2 = "SELECT distinct(habitat) as habitat FROM pokemon order by 1";
        String cuerito2 = "SELECT distinct(habitat) as habitat FROM pokemon order by 1";
        try {
            resultadoConsulta = estado.executeQuery(cuerito2);
            
          while (resultadoConsulta.next()){
                jcomboHabitats.remove(this);
                jcomboHabitats.addItem(resultadoConsulta.getString("habitat"));
            }
           
            
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            System.out.println("Clavo con sql");        // TODO add your handling code here:
    }//GEN-LAST:event_pruebaActionPerformed
    }        
    private void jcomboHabitatsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcomboHabitatsActionPerformed
         String habit=(String)jcomboHabitats.getSelectedItem();    
       
             jcomboPokemones.removeAllItems();
              String cuerito1 ="SELECT  name from pokemon where habitat='"+habit+"'" ;
             
                         
        try {
            resultadoConsulta = estado.executeQuery(cuerito1);
            
            
          while (resultadoConsulta.next()){
                 jcomboPokemones.remove(this);
                jcomboPokemones.addItem(resultadoConsulta.getString("name"));
            }
           
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            System.out.println("Clavo con sql");        // TODO add your handling code here:
                }    
        
        
         
        
         
           
                       // TODO add your handling code here:
    }//GEN-LAST:event_jcomboHabitatsActionPerformed

    private void btncolorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncolorActionPerformed
       String cuerito3 = "SELECT DISTINCT (color) as color FROM pokemon order by 1";//ordena alfabeticamente los colores
        try {
            resultadoConsulta = estado.executeQuery(cuerito3);
            
          while (resultadoConsulta.next()){
                 jcombocolor.remove(this);
                jcombocolor.addItem(resultadoConsulta.getString("color"));
            }
           
            
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            System.out.println("Clavo con sql");
                    }
// TODO add your handling code here:
    }//GEN-LAST:event_btncolorActionPerformed

    private void jcombocolorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcombocolorActionPerformed
        
        String habit=(String)jcombocolor.getSelectedItem();    
         jcomboPokemones.removeAllItems();
              String cuerito1 ="SELECT  name from pokemon where color='"+habit+"'" ;
              
           try {
                resultadoConsulta = estado.executeQuery(cuerito1);
            } catch (SQLException ex) {
                Logger.getLogger(ventana_pokedex.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            try {
                while (resultadoConsulta.next()){
                     jcomboPokemones.remove(this);
                    jcomboPokemones.addItem(resultadoConsulta.getString("name"));
                }
                
                // TODO add your handling code here:
                // TODO add your handling code here:
            } catch (SQLException ex) {
                Logger.getLogger(ventana_pokedex.class.getName()).log(Level.SEVERE, null, ex);
            
    }//GEN-LAST:event_jcombocolorActionPerformed
    }
    private void btnbuscarNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbuscarNombreActionPerformed
          String cuerito3 = "SELECT DISTINCT (name) as name FROM pokemon order by 1";//ordena alfabeticamente los colores
        try {
            resultadoConsulta = estado.executeQuery(cuerito3);
            
          while (resultadoConsulta.next()){
                 jcomboNombres.remove(this);
                jcomboNombres.addItem(resultadoConsulta.getString("name"));
            }
           
            
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            System.out.println("Clavo con sql");
                    }
        
        
            
            
                     
    }//GEN-LAST:event_btnbuscarNombreActionPerformed

    private void jcomboPokemonesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcomboPokemonesActionPerformed
                
        
    }//GEN-LAST:event_jcomboPokemonesActionPerformed
             
    private void jcomboNombresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcomboNombresActionPerformed
               String habit=(String)jcomboNombres.getSelectedItem();  
                jcombocolor.removeAllItems();
              
              String cuerito1 ="SELECT  id, name, habitat,color,species,capture_rate,base_experience from pokemon where name='"+habit+"'" ;
              
           try {
                resultadoConsulta = estado.executeQuery(cuerito1);
            } catch (SQLException ex) {
                Logger.getLogger(ventana_pokedex.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            try {
                while (resultadoConsulta.next()){
                     jcombocolor.remove(this);
                    //jcombocolor.addItem(resultadoConsulta.getString("name"));
                    String f;
                   f=(resultadoConsulta.getString("id"));
                   
                   contador= Integer.parseInt(f) ;
                     dibujaElPokemonQueEstaEnLaPosicion(contador);
                    // nombrePoke.setText(resultadoConsulta.getString("name"));
                      //query.setText(resultadoConsulta.getString("habitat"));
                     query.setText(resultadoConsulta.getString("habitat"));
                    nombrePoke.setText(resultadoConsulta.getString("name"));
                     lblcolor.setText(resultadoConsulta.getString("color"));
                     lblspecies.setText(resultadoConsulta.getString("species"));
                     lblcapture_rate.setText(resultadoConsulta.getString("capture_rate"));
                     lblbase_experience.setText(resultadoConsulta.getString("base_experience"));
                      lblcolor.setVisible(true);
                       lblspecies.setVisible(true);
                      lblcapture_rate.setVisible(true);
                     lblbase_experience.setVisible(true);
        
        contador++;
        if (contador >=649){
            contador = 649;
        }
                
                       
                      
                }
                
                
                // TODO add your handling code here:
                // TODO add your handling code here:
            } catch (SQLException ex) {
                Logger.getLogger(ventana_pokedex.class.getName()).log(Level.SEVERE, null, ex);        // TODO add your handling code here:
    }//GEN-LAST:event_jcomboNombresActionPerformed
    }
    private void btnfavoritosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfavoritosActionPerformed
                  clsinsertar agregar=new clsinsertar();//variable agregar que va a llevar todos lod datos ingresados
               
                   
                   agregar.setColorU(lblcolor.getText());
                   agregar.setFavoritos(nombrePoke.getText());
                   agregar.setBase_experienceU(lblbase_experience.getText());
                   agregar.setCapture_rateU(lblcapture_rate.getText());
                   agregar.setHabitatU(query.getText());
                   agregar.setSpeciesU(lblspecies.getText());
                  
                   clsverificar alJDBC=new clsverificar();
                   
                   alJDBC.insert(agregar);//llamamos a la función insert con el parametro agregar
                   
                   JOptionPane.showMessageDialog(null,"pokemon agregado a favoritos");
                   setVisible(false);
              ventana_pokedex interfaz = new ventana_pokedex();
                 interfaz.setVisible(true);
   // TODO add your handling code here:
    }//GEN-LAST:event_btnfavoritosActionPerformed

        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
         /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
         try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ventana_pokedex.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ventana_pokedex.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ventana_pokedex.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ventana_pokedex.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ventana_pokedex.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ventana_pokedex.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ventana_pokedex.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ventana_pokedex.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ventana_pokedex().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnbuscarNombre;
    private javax.swing.JButton btncolor;
    private javax.swing.JButton btnfavoritos;
    private javax.swing.JButton derecha;
    private javax.swing.JPanel imagenPoke;
    private javax.swing.JButton izquierda;
    private javax.swing.JComboBox<String> jcomboHabitats;
    private javax.swing.JComboBox<String> jcomboNombres;
    private javax.swing.JComboBox<String> jcomboPokemones;
    private javax.swing.JComboBox<String> jcombocolor;
    private javax.swing.JLabel lblbase_experience;
    private javax.swing.JLabel lblcapture_rate;
    javax.swing.JLabel lblcolor;
    private javax.swing.JLabel lblprueba;
    private javax.swing.JLabel lblspecies;
    private javax.swing.JLabel nombrePoke;
    private javax.swing.JLabel nombrepoke;
    private javax.swing.JButton prueba;
    private javax.swing.JLabel query;
    // End of variables declaration//GEN-END:variables
}
